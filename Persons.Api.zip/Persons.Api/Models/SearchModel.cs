﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Persons.Api.Models
{
    public class SearchModel
    {
        public string SearchString;
    }
}
