﻿using System;

namespace Events
{
    public class PhotoDeleteEvent
    {
        public string Id;
    }
}
