﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Enums
{
    public enum SalaryType
    {
        A6 = 1,
        A7 = 2,
        A8 = 3,
        A9 = 4
    }
}
